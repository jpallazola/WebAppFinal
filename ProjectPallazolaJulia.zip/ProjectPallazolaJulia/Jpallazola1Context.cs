﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using ProjectPallazolaJulia.Pages.tblActivity;
using ProjectPallazolaJulia.Pages.tblActivityLog;
using ProjectPallazolaJulia.Pages.tblConnection;
using ProjectPallazolaJulia.Pages.tblNutrition;
using ProjectPallazolaJulia.Pages.tblUser;
using ProjectPallazolaJulia.Pages.Views;

namespace ProjectPallazolaJulia;

public partial class Jpallazola1Context : DbContext
{
    public Jpallazola1Context(DbContextOptions<Jpallazola1Context> options) : base(options)
    {
    }

    public virtual DbSet<TblActivity> TblActivities { get; set; }

    public virtual DbSet<TblActivityLog> TblActivityLogs { get; set; }

    public virtual DbSet<TblConnection> TblConnections { get; set; }

    public virtual DbSet<TblNutrition> TblNutritions { get; set; }

    public virtual DbSet<TblUser> TblUsers { get; set; }

    public virtual DbSet<VwActivity> VwActivities { get; set; }

    public virtual DbSet<VwNetCalory> VwNetCalories { get; set; }

    public virtual DbSet<VwNutrition> VwNutritions { get; set; }

    public virtual DbSet<VwUser> VwUsers { get; set; }

    public IConfiguration myconfig { get; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer(myconfig.GetConnectionString("PallazolaConnection"));
        }

    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TblActivity>(entity =>
        {
            entity.HasKey(e => e.ActivityId).HasName("PK__tblActiv__45F4A7F1D3EB26CF");

            entity.ToTable("tblActivities");

            entity.Property(e => e.ActivityId).HasColumnName("ActivityID");
            entity.Property(e => e.ActivityName)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.CaloriesBurnedPerHour)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
        });

        modelBuilder.Entity<TblActivityLog>(entity =>
        {
            entity.HasKey(e => e.LogId).HasName("PK__tblActiv__5E5499A83003C460");

            entity.ToTable("tblActivityLog");

            entity.Property(e => e.LogId).HasColumnName("LogID");
            entity.Property(e => e.ActivityId).HasColumnName("ActivityID");
            entity.Property(e => e.CaloriesBurned)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Duration)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.Activity).WithMany(p => p.TblActivityLogs)
                .HasForeignKey(d => d.ActivityId)
                .HasConstraintName("FK__tblActivi__Activ__03F0984C");

            entity.HasOne(d => d.User).WithMany(p => p.TblActivityLogs)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__tblActivi__UserI__02FC7413");
        });


        modelBuilder.Entity<TblConnection>(entity =>
        {
            entity.HasKey(e => e.UserActivityLogId).HasName("PK__tblConne__488B2473EEB5FAF1");

            entity.ToTable("tblConnections");

            entity.Property(e => e.UserActivityLogId).HasColumnName("UserActivityLogID");
            entity.Property(e => e.LogId).HasColumnName("LogID");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.Log).WithMany(p => p.TblConnections)
                .HasForeignKey(d => d.LogId)
                .HasConstraintName("FK__tblConnec__LogID__07C12930");

            entity.HasOne(d => d.User).WithMany(p => p.TblConnections)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__tblConnec__UserI__06CD04F7");
        });


        modelBuilder.Entity<TblNutrition>(entity =>
        {
            entity.HasKey(e => e.LogId).HasName("PK__tblNutri__5E5499A85A5189C7");

            entity.ToTable("tblNutrition");

            entity.Property(e => e.LogId).HasColumnName("LogID");
            entity.Property(e => e.Calories)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.FoodName)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User).WithMany(p => p.TblNutritions)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__tblNutrit__UserI__00200768");
        });


        modelBuilder.Entity<TblUser>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__tblUser__1788CCAC3F81B374");

            entity.ToTable("tblUser");

            entity.Property(e => e.UserId).HasColumnName("UserID");
            entity.Property(e => e.Age)
                .HasMaxLength(3)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Gender)
                .HasMaxLength(1)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Height)
                .HasMaxLength(3)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.UserName)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Weight)
                .HasMaxLength(3)
                .IsUnicode(false)
                .IsFixedLength();
        });

        modelBuilder.Entity<VwActivity>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("VwActivities");

            entity.Property(e => e.ActivityName)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.CaloriesBurnedPerHour)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
        });

        modelBuilder.Entity<VwNetCalory>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("VwNetCalories");
            entity.Property(e => e.ActivityId).HasColumnName("ActivityID");
            entity.Property(e => e.Calories)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CaloriesBurned)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Duration)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.FoodName)
                .HasMaxLength(40)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VwNutrition>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("VwNutrition");

            entity.Property(e => e.Calories)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.FoodName)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.UserId).HasColumnName("UserID");
        });

        modelBuilder.Entity<VwUser>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("VwUser");

            entity.Property(e => e.Age)
                .HasMaxLength(3)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Gender)
                .HasMaxLength(1)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Height)
                .HasMaxLength(3)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.UserId)
                .ValueGeneratedOnAdd()
                .HasColumnName("UserID");
            entity.Property(e => e.UserName)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Weight)
                .HasMaxLength(3)
                .IsUnicode(false)
                .IsFixedLength();
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}