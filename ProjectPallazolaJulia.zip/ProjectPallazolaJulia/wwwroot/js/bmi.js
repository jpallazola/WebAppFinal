﻿document.getElementById("calculateBtn").addEventListener("click", calculateBMI);

function calculateBMI() {
    var heightInInches = parseFloat(document.getElementById("height").value);
    var weightInPounds = parseFloat(document.getElementById("weight").value);

    if (isNaN(heightInInches) || isNaN(weightInPounds) || heightInInches <= 0 || weightInPounds <= 0) {
        document.getElementById("result").innerHTML = "Please enter valid height and weight.";
        return;
    }

    var bmi = (weightInPounds / (heightInInches * heightInInches)) * 703;
    var bmiCategory = getBMICategory(bmi);

    document.getElementById("result").innerHTML = "Your BMI is: " + bmi.toFixed(2) + ". You are in the " + bmiCategory + " category.";
}

function getBMICategory(bmi) {
    if (bmi < 18.5) {
        return "Underweight";
    } else if (bmi >= 18.5 && bmi < 24.9) {
        return "Normal weight";
    } else if (bmi >= 24.9 && bmi < 29.9) {
        return "Overweight";
    } else {
        return "Obese";
    }
}
