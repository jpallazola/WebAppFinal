using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectPallazolaJulia.Pages
{
    public class landingPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
