﻿using System;
using System.Collections.Generic;
using ProjectPallazolaJulia.Pages.tblActivityLog;
using ProjectPallazolaJulia.Pages.tblConnection;
using ProjectPallazolaJulia.Pages.tblNutrition;

namespace ProjectPallazolaJulia.Pages.tblUser;

public partial class TblUser
{
    public int UserId { get; set; }

    public string? UserName { get; set; }

    public string? Age { get; set; }

    public string? Gender { get; set; }

    public string? Height { get; set; }

    public string? Weight { get; set; }

    public virtual ICollection<TblActivityLog> TblActivityLogs { get; set; } = new List<TblActivityLog>();

    public virtual ICollection<TblConnection> TblConnections { get; set; } = new List<TblConnection>();

    public virtual ICollection<TblNutrition> TblNutritions { get; set; } = new List<TblNutrition>();
}
