﻿using System;
using System.Collections.Generic;
using ProjectPallazolaJulia.Pages.tblActivityLog;

namespace ProjectPallazolaJulia.Pages.tblActivity;

public partial class TblActivity
{
    public int ActivityId { get; set; }

    public string? ActivityName { get; set; }

    public string? CaloriesBurnedPerHour { get; set; }

    public virtual ICollection<TblActivityLog> TblActivityLogs { get; set; } = new List<TblActivityLog>();
}
