﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProjectPallazolaJulia;

namespace ProjectPallazolaJulia.Pages.tblActivity
{
    public class IndexModel : PageModel
    {
        private readonly ProjectPallazolaJulia.Jpallazola1Context _context;

        public IndexModel(ProjectPallazolaJulia.Jpallazola1Context context)
        {
            _context = context;
        }

        public IList<TblActivity> TblActivity { get;set; } = default!;

        public async Task OnGetAsync()
        {
            TblActivity = await _context.TblActivities.ToListAsync();
        }
    }
}
