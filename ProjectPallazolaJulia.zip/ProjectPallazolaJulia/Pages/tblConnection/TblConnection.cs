﻿using System;
using System.Collections.Generic;
using ProjectPallazolaJulia.Pages.tblActivityLog;
using ProjectPallazolaJulia.Pages.tblUser;

namespace ProjectPallazolaJulia.Pages.tblConnection;

public partial class TblConnection
{
    public int UserActivityLogId { get; set; }

    public int? UserId { get; set; }

    public int? LogId { get; set; }

    public virtual TblActivityLog? Log { get; set; }

    public virtual TblUser? User { get; set; }
}
