﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProjectPallazolaJulia;

namespace ProjectPallazolaJulia.Pages.tblNutrition
{
    public class DeleteModel : PageModel
    {
        private readonly ProjectPallazolaJulia.Jpallazola1Context _context;

        public DeleteModel(ProjectPallazolaJulia.Jpallazola1Context context)
        {
            _context = context;
        }

        [BindProperty]
        public TblNutrition TblNutrition { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblnutrition = await _context.TblNutritions.FirstOrDefaultAsync(m => m.LogId == id);

            if (tblnutrition == null)
            {
                return NotFound();
            }
            else
            {
                TblNutrition = tblnutrition;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblnutrition = await _context.TblNutritions.FindAsync(id);
            if (tblnutrition != null)
            {
                TblNutrition = tblnutrition;
                _context.TblNutritions.Remove(TblNutrition);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
