﻿using System;
using System.Collections.Generic;
using ProjectPallazolaJulia.Pages.tblUser;

namespace ProjectPallazolaJulia.Pages.tblNutrition;

public partial class TblNutrition
{
    public int LogId { get; set; }

    public int? UserId { get; set; }

    public string? FoodName { get; set; }

    public string? Calories { get; set; }

    public DateOnly? Date { get; set; }

    public virtual TblUser? User { get; set; }
}
