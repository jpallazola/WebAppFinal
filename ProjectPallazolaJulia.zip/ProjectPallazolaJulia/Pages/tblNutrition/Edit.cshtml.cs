﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProjectPallazolaJulia;

namespace ProjectPallazolaJulia.Pages.tblNutrition
{
    public class EditModel : PageModel
    {
        private readonly ProjectPallazolaJulia.Jpallazola1Context _context;

        public EditModel(ProjectPallazolaJulia.Jpallazola1Context context)
        {
            _context = context;
        }

        [BindProperty]
        public TblNutrition TblNutrition { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblnutrition =  await _context.TblNutritions.FirstOrDefaultAsync(m => m.LogId == id);
            if (tblnutrition == null)
            {
                return NotFound();
            }
            TblNutrition = tblnutrition;
           ViewData["UserId"] = new SelectList(_context.TblUsers, "UserId", "UserId");
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(TblNutrition).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TblNutritionExists(TblNutrition.LogId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool TblNutritionExists(int id)
        {
            return _context.TblNutritions.Any(e => e.LogId == id);
        }
    }
}
