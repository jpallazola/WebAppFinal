﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ProjectPallazolaJulia;

namespace ProjectPallazolaJulia.Pages.tblActivityLog
{
    public class CreateModel : PageModel
    {
        private readonly ProjectPallazolaJulia.Jpallazola1Context _context;

        public CreateModel(ProjectPallazolaJulia.Jpallazola1Context context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
        ViewData["ActivityId"] = new SelectList(_context.TblActivities, "ActivityId", "ActivityId");
        ViewData["UserId"] = new SelectList(_context.TblUsers, "UserId", "UserId");
            return Page();
        }

        [BindProperty]
        public TblActivityLog TblActivityLog { get; set; } = default!;

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.TblActivityLogs.Add(TblActivityLog);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
