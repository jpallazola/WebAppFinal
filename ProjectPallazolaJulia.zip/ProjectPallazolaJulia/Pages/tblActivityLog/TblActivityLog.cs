﻿using System;
using System.Collections.Generic;
using ProjectPallazolaJulia.Pages.tblActivity;
using ProjectPallazolaJulia.Pages.tblConnection;
using ProjectPallazolaJulia.Pages.tblUser;

namespace ProjectPallazolaJulia.Pages.tblActivityLog;

public partial class TblActivityLog
{
    public int LogId { get; set; }

    public int? UserId { get; set; }

    public int? ActivityId { get; set; }

    public string? Duration { get; set; }

    public string? CaloriesBurned { get; set; }

    public DateOnly? Date { get; set; }

    public virtual TblActivity? Activity { get; set; }

    public virtual ICollection<TblConnection> TblConnections { get; set; } = new List<TblConnection>();

    public virtual TblUser? User { get; set; }
}
