﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProjectPallazolaJulia;

namespace ProjectPallazolaJulia.Pages.tblActivityLog
{
    public class DeleteModel : PageModel
    {
        private readonly ProjectPallazolaJulia.Jpallazola1Context _context;

        public DeleteModel(ProjectPallazolaJulia.Jpallazola1Context context)
        {
            _context = context;
        }

        [BindProperty]
        public TblActivityLog TblActivityLog { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblactivitylog = await _context.TblActivityLogs.FirstOrDefaultAsync(m => m.LogId == id);

            if (tblactivitylog == null)
            {
                return NotFound();
            }
            else
            {
                TblActivityLog = tblactivitylog;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblactivitylog = await _context.TblActivityLogs.FindAsync(id);
            if (tblactivitylog != null)
            {
                TblActivityLog = tblactivitylog;
                _context.TblActivityLogs.Remove(TblActivityLog);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
