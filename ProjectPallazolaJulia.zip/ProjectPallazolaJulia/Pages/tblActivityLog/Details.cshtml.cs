﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProjectPallazolaJulia;

namespace ProjectPallazolaJulia.Pages.tblActivityLog
{
    public class DetailsModel : PageModel
    {
        private readonly ProjectPallazolaJulia.Jpallazola1Context _context;

        public DetailsModel(ProjectPallazolaJulia.Jpallazola1Context context)
        {
            _context = context;
        }

        public TblActivityLog TblActivityLog { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tblactivitylog = await _context.TblActivityLogs.FirstOrDefaultAsync(m => m.LogId == id);
            if (tblactivitylog == null)
            {
                return NotFound();
            }
            else
            {
                TblActivityLog = tblactivitylog;
            }
            return Page();
        }
    }
}
