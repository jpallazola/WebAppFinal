using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProjectPallazolaJulia.Pages.Views;

namespace ProjectPallazolaJulia.Pages.Data_Visualization.Views
{
    public class UserModel : PageModel
    {
        private readonly ProjectPallazolaJulia.Jpallazola1Context _context;
        public UserModel(ProjectPallazolaJulia.Jpallazola1Context context)
        {
            _context = context;
        }
        public IList<VwUser> VwUser { get; set; }
        public async Task OnGetAsync()
        {
            VwUser = await _context.VwUsers.ToListAsync();
        }
    }
}
