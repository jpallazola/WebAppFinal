﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace ProjectPallazolaJulia.Pages.Views;

public partial class VwUser
{
    [Display(Name = "User Name")]
    public string? UserName { get; set; }

    [Display(Name = "User ID")]
    public int UserId { get; set; }

    [Display(Name = "Age")]
    public string? Age { get; set; }

    [Display(Name = "Gender")]
    public string? Gender { get; set; }

    [Display(Name = "Height (in)")]
    public string? Height { get; set; }

    [Display(Name = "Weight")]
    public string? Weight { get; set; }
}
