using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProjectPallazolaJulia.Pages.Views;

namespace ProjectPallazolaJulia.Pages.Data_Visualization.Views
{
    public class ActivityModel : PageModel
    {
        private readonly ProjectPallazolaJulia.Jpallazola1Context _context;
        public ActivityModel(ProjectPallazolaJulia.Jpallazola1Context context)
        {
            _context = context;
        }
        public IList<VwActivity> VwActivity { get; set; }
        public async Task OnGetAsync()
        {
            VwActivity = await _context.VwActivities.ToListAsync();
        }
    }
}
