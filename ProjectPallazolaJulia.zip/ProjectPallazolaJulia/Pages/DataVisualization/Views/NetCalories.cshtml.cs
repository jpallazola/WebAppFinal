using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProjectPallazolaJulia.Pages.Views;

namespace ProjectPallazolaJulia.Pages.Data_Visualization.Views
{
    public class NetCaloriesModel : PageModel
    {
        private readonly ProjectPallazolaJulia.Jpallazola1Context _context;
        public NetCaloriesModel(ProjectPallazolaJulia.Jpallazola1Context context)
        {
            _context = context;
        }
        public IList<VwNetCalory> VwNetCalory { get; set; }
        public async Task OnGetAsync()
        {
            VwNetCalory = await _context.VwNetCalories.ToListAsync();
        }
    }
}
