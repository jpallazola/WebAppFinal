﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace ProjectPallazolaJulia.Pages.Views;

public partial class VwNutrition
{
    [Display(Name = "Food Name")]
    public string? FoodName { get; set; }


    [Display(Name = "Calories")]
    public string? Calories { get; set; }


    [Display(Name = "Date")]
    public DateOnly? Date { get; set; }

    [Display(Name = "User ID")]
    public int? UserId { get; set; }
}
