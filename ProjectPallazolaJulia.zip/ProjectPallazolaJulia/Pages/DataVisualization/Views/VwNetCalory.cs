﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace ProjectPallazolaJulia.Pages.Views;

public partial class VwNetCalory
{
    [Display(Name = "Activity ID")]
    public int? ActivityId { get; set; }

    [Display(Name = "Duration (Min)")]
    public string? Duration { get; set; }

    [Display(Name = "Calories Burned")]
    public string? CaloriesBurned { get; set; }

    [Display(Name = "Activity Date")]
    public DateOnly? ActivityDate { get; set; }

    [Display(Name = "Food Name")]
    public string? FoodName { get; set; }


    [Display(Name = "Calories")]
    public string? Calories { get; set; }

    [Display(Name = "Food Date")]
    public DateOnly? FoodDate { get; set; }
}
