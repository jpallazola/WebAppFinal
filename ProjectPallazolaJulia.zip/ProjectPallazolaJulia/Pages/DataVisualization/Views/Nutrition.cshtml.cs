using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProjectPallazolaJulia.Pages.Views;

namespace ProjectPallazolaJulia.Pages.Data_Visualization.Views
{
    public class NutritionModel : PageModel
    {
        private readonly ProjectPallazolaJulia.Jpallazola1Context _context;
        public NutritionModel(ProjectPallazolaJulia.Jpallazola1Context context)
        {
            _context = context;
        }
        public IList<VwNutrition> VwNutrition { get; set; }
        public async Task OnGetAsync()
        {
            VwNutrition = await _context.VwNutritions.ToListAsync();
        }
    }
}
