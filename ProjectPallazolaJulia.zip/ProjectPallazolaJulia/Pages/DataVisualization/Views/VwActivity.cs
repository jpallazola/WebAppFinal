﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace ProjectPallazolaJulia.Pages.Views;

public partial class VwActivity
{
    [Display(Name = "Activity Name" )]
    public string? ActivityName { get; set; }


    [Display(Name = "Calories Burned Per Hour")]
    public string? CaloriesBurnedPerHour { get; set; }
}

