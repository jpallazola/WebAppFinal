using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectPallazolaJulia.Pages.Shared
{
    public class tblLayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
